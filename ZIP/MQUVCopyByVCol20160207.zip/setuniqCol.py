#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright (c) 2013, a
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
# * Redistributions of source code must retain the above copyright notice, 
#   this list of conditions and the following disclaimer.
# * Redistributions in binary form must reproduce the above copyright notice, 
#   this list of conditions and the following disclaimer in the documentation 
#   and/or other materials provided with the distribution.
# * Neither the name of the <organization> nor the　names of its contributors 
#   may be used to endorse or promote products derived from this software 
#   without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import sys
sys.path.append('.')


doc = MQSystem.getDocument()

numVertex = 0
for o in doc.object:
  numVertex = numVertex + len(o.vertex)

if numVertex>=250*250*250:
  print("Err: 頂点が多すぎる")
  exit()

colArr = []
for i in range(0, numVertex):
  fColArr = []
  c = 0
  if i!=0:
    c=(i/numVertex)*((250*250*250)-1)
  if c >= (250*250):
    fColArr.append((c/(250*250)) / 250.0)
  else:
    fColArr.append(0)
  c = c%(250*250)
  if c >= 250:
    fColArr.append((c/250) / 250.0)
  else:
    fColArr.append(0)
  fColArr.append((c%250) / 250.0)
  colArr.append(fColArr)

dArr = []
for i in range(0, numVertex):
  dArr.append(0)

for o in doc.object:
  for f in o.face:
    for i in range(0, f.numVertex):
      vi = f.index[i]
      col = f.color[i]
      colSrc = colArr[vi]
      dArr[vi] = dArr[vi]+1
      col.red = colSrc[0]
      col.green = colSrc[1]
      col.blue = colSrc[2]
  colArr = colArr[len(o.vertex):]
